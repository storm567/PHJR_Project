/**
 * 基础对外模型
 */
module.exports = {
	PayResult: require('./payResult'),
}
