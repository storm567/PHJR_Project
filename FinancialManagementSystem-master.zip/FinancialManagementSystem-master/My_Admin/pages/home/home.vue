<template>
  <view>
    <LoanChart />
  </view>
</template>

<script setup>
import LoanChart from '@/components/LoanCharts.vue'; // 根据实际路径调整
</script>

<style>
/* 页面样式 */
</style>
